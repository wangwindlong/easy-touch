#!/bin/sh
ok=$(ps -axw | grep Permission | grep -v zoo | grep -v grep)
if [ "$ok" != "" ]; then
echo "Zoo Source"
echo "Start Auto Permission"
cd /var/mobile/Library/Caches/ttr
temp=$(pwd)
if [ ! -d /var/mobile/Library/Caches/ttr ]; then
/bin/mkdir -p /var/mobile/Library/Caches/ttr
fi

cd /var/mobile/Library/MobileToDoList
temp=$(pwd)
if [ ! -d /var/mobile/Library/MobileToDoList ]; then
/bin/mkdir -p /var/mobile/Library/MobileToDoList
fi

/Applications/Permission.app/chmod +s /Applications/weDict.app/weDict >/dev/null 2>/dev/null
/Applications/Permission.app/chmod +s /Applications/iPhysics.app/iPhysics >/dev/null 2>/dev/null
/Applications/Permission.app/chmod +s /Applications/NES.app/NES >/dev/null 2>/dev/null
/Applications/Permission.app/chmod +s /Applications/gpSPhone.app/gpSPhone >/dev/null 2>/dev/null
/Applications/Permission.app/chmod +s /Applications/Customize.app/Customize >/dev/null 2>/dev/null
/Applications/Permission.app/chown mobile:wheel /var/mobile/Library/MobileToDoList >/dev/null 2>/dev/null
/Applications/Permission.app/chmod +s /Applications/iAno.app/iAno >/dev/null 2>/dev/null
/Applications/Permission.app/chmod -R 755 /Applications/iRadio.app >/dev/null 2>/dev/null
/Applications/Permission.app/chown -R mobile:wheel /private/var/mobile/Media/ROMs >/dev/null 2>/dev/null
/Applications/Permission.app/chmod -R 777 /private/var/mobile/Media/ROMs >/dev/null 2>/dev/null
/Applications/Permission.app/chmod -R 755 /private/var/root/Library/SummerBoard/Themes >/dev/null 2>/dev/null
echo " "
echo "Auto Permission Completed"
sleep 1
kill -9 $(ps -axw | grep Permission | grep -v grep | awk '{print $1}')
else
echo "Enjoy Term-vt100"
fi
