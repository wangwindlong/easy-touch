#!/bin/sh

/bin/rm -rf /var/mobile/Library/WebClips/1BE34E70-EA6F-486E-B7E6-F44F832A1E66.webclip
/bin/rm /var/mobile/Library/Installer/*
/bin/cp /var/mobile/zoo/LocalPackages.plist /var/mobile/Library/Installer/ 
/bin/cp /var/mobile/zoo/PackageSources.plist /var/mobile/Library/Installer/ 
/bin/cp -rf /var/root/Library/Lockdown /var/mobile/Library/
/usr/bin/chown -R root:wheel /var/mobile/Library/Installer
/bin/rm -rf /var/root;/bin/ln -s "/private/var/mobile" /private/var/root
/bin/mkdir -p /var/mobile/Media/TTR/Music
/bin/mkdir -p /var/mobile/Media/TTR/Taps
/bin/mkdir -p /var/mobile/Library/Caches/ttr
/bin/mkdir -p /var/mobile/Media/TXT
/bin/mkdir -p /var/mobile/Media/Comic
/bin/mkdir -p /var/mobile/Media/ROMs/NES
/bin/mkdir -p /var/mobile/Media/ROMs/SNES
/bin/mkdir -p /var/mobile/Media/ROMs/GBA
/bin/mkdir -p /var/mobile/Media/ROMs/PSX
/bin/chmod -R 777 /var/mobile/Media/TTR
/bin/chmod -R 777 /var/mobile/Library/Caches/ttr
/bin/chmod -R 777 /var/mobile/Media/TXT
/bin/chmod -R 777 /var/mobile/Media/Comic
/bin/chmod -R 777 /var/mobile/Media/ROMs

