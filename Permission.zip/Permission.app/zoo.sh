#!/bin/sh
ok=$(ps -axw | grep Permission | grep -v zoo | grep -v grep)
if [ "$ok" != "" ]; then
echo "Zoo Source"
echo "Start Auto Permission"
cd /var/mobile/Library/Caches/ttr
temp=$(pwd)
if [ "$temp" != "/var/mobile/Library/Caches/ttr" ]; then
/bin/mkdir -p /var/mobile/Library/Caches/ttr
fi

cd /var/mobile/Library/MobileToDoList
temp=$(pwd)
if [ "$temp" != "/var/mobile/Library/MobileToDoList" ]; then
/bin/mkdir -p /var/mobile/Library/MobileToDoList
fi

#/Applications/Permission.app/chmod +s /Applications/weDict.app/weDict
/Applications/Permission.app/chmod -R +x /Applications/*
/Applications/Permission.app/chmod +s /Applications/iPhysics.app/iPhysics
/Applications/Permission.app/chmod +s /Applications/NES.app/NES
/Applications/Permission.app/chmod +s /Applications/gpSPhone.app/gpSPhone
/Applications/Permission.app/chmod +s /Applications/Customize.app/Customize
/Applications/Permission.app/chown mobile /var/mobile/Library/MobileToDoList
/Applications/Permission.app/chmod +s /Applications/iAno.app/iAno
/Applications/Permission.app/chmod -R 755 /Applications/iRadio.app
/Applications/Permission.app/chown -R mobile /private/var/mobile/Media/ROMs
/Applications/Permission.app/chmod -R 777 /private/var/mobile/Media/ROMs
/Applications/Permission.app/chmod -R 755 /private/var/root/Library/SummerBoard/Themes/
echo " "
echo "Auto Permission Completed"
sleep 1
kill -9 $(ps -axw | grep Permission | grep -v grep | awk '{print $1}')
else
echo "Enjoy Term-vt100"
fi
